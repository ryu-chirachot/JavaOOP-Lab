package test;

public interface Sugar {
	public void putSugar();
	public void putSugar(int spoon);

}
