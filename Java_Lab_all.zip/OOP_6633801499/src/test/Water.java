package test;

public interface Water {
	public void putWater();
	public void putWater(int it);
}
