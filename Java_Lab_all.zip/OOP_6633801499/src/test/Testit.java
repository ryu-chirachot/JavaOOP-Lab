package test;

public class Testit implements Ex {

	@Override
	public int met1() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int met2() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String m3(int x, int y, int z) {
		// TODO Auto-generated method stub
		return null;
	}

}
