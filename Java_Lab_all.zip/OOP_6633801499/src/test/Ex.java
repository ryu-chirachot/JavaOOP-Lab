package test;

public interface Ex {
	final double PI = 3.14;
	public int met1();
	public int met2();
	public String m3(int x, int y, int z);

}
