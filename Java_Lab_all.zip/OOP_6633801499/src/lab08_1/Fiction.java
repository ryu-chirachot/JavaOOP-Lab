package lab08_1;

public class Fiction implements Book {

	@Override
	public String getContent() {
		// TODO Auto-generated method stub
		return "\"Easy Hacking\" is a Textbook's content from "+PUBLISHER+".";
	}

}
