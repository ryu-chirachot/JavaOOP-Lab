package lab08_1;

public interface Book {
	final String PUBLISHER = "IT Publishing";
	
	public String getContent();
	

}
