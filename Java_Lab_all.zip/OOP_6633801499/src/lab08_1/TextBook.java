package lab08_1;

public class TextBook implements Book {

	@Override
	public String getContent() {
		// TODO Auto-generated method stub
		return "MC^2 is a Fiction's content from "+PUBLISHER+".";
	}

}
