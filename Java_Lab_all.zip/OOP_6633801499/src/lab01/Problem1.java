package lab01;

public class Problem1 {

	public static void main(String[] args) {
		String Name = "Mary Jane";
		int year = 2003;
		String Stuid = "660000000-0";
		System.out.println("My name is "+Name+".");
		System.out.printf("I was born in %d.",year);
		System.out.print("\nMy student id is "+Stuid+".");
	}

}
